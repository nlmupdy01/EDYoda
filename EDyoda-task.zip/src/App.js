
import Edyodaamt from "./Pages/EdAmount";
import Navbar from "./components/Navbar"

function App() {
  return (
   
    <>
    <Navbar />
   <Edyodaamt />
    </>
  );
}

export default App;

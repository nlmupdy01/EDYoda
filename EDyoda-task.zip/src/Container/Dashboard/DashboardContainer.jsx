import React, { Component } from 'react'
// import DownloadExtFile from '../../components/Common/DownloadExtFile'
import TableContainer from '../Table/TableContainer'

export default class DashboardContainer extends Component {
  render() {
    return (
      <div
      
      ><TableContainer/>
{/* <DownloadExtFile /> */}
      </div>
    )
  }
}

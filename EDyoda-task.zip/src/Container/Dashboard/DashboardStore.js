// import MyAction from "../../Store/Action"
// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";

// const mapStateToProps= (state) => {
//     return {
//         myName: state.myReducer.myName,
//         loaded: state.myReducer.name.isLoaded
//     };
// };

// const mapDispatchToProps = (dispatch) => bindActionCreators(
//     {
//         getNameAction:MyAction.getName,
//         eraseNameAction:MyAction.eraseName
//     },
//     dispatch
// );

// const DashboaredStore = (container) => connect(mapStateToProps, mapDispatchToProps)(container);

// export default DashboaredStore;


import React, { Component } from "react";
import { Stack, Box, Input } from '@mui/material';
import AmountCard from "../../components/Amountcard";
import EdyodaContent from "../../components/EdyodaContent";


class EdAmountContainer extends Component {

  render() {
    return (

      <>

        <Stack direction="row" spacing={2}>
          
          <Box sx={{ width: '60%' , mt:5 }}>
         
          <EdyodaContent />
          </Box>

          <Box sx={{ width: '30%', mt :5,}}>
          
       
<AmountCard />
            {/* <form className="form" onSubmit={e => {
              this.handleSubmit(e);
            }}>

              <Textfields type="text"
                label="User Name"
                name="username"

                value={Input.username}
                 />
              <FormHelperText id="username-helper">
                Username is by Default admin
              </FormHelperText>
<span></span>

              <Box sx={{ marginTop: 2 }}>
                <Textfields type="password"
                  label="Password"
                  value={Input.password}
                  name="password"
              
                />
                <FormHelperText id="username-helper">
                  Password is One to Five number
                </FormHelperText>
              </Box>
              <CommonButton ButtonTxt="Login"
              />
               <CommonButton ButtonTxt="Login"
              />
            </form> */}

          </Box>

        </Stack>

      </>
    );
  }
}

export default EdAmountContainer;

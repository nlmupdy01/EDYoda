import EdAmountContainer from "./EdAmountContainer";
export default EdAmount;

import React from "react";
import { connect } from "react-redux";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Typography
  
} from '@mui/material';

class TableContainer extends React.Component {

  
  render() 
  {

    const { rows } = this.props;

    return (
    <>
        <Table sx={{ width: 800, marginLeft: 35 }} >
          <TableHead >
            <TableRow    sx={{background:'#1976d2'  }}>


              <TableCell>
              <Typography  fontSize={'15px'} sx={{fontWeight:550 ,color:'#ffffff'}}>
                ID
                </Typography>
              </TableCell>
              <TableCell>
              <Typography  fontSize={'15px'} sx={{fontWeight:550 ,color:'#ffffff'}}>
                Name
                </Typography>
              </TableCell>
              <TableCell>
              <Typography  fontSize={'15px'} sx={{fontWeight:550 ,color:'#ffffff'}}>
                Email
                </Typography>
              </TableCell>
              <TableCell>
              <Typography  fontSize={'15px'} sx={{fontWeight:550 ,color:'#ffffff'}}>
                Mobile No
                </Typography>
              </TableCell>
              <TableCell>
              <Typography  fontSize={'15px'} sx={{fontWeight:550 ,color:'#ffffff'}}>
                Address
                </Typography>
              </TableCell>
            </TableRow>

          </TableHead>
          <TableBody>
          {rows.map((row, index) => (
             
            <TableRow  key={index}>
              <TableCell>
              {row.id}

              </TableCell>
              <TableCell>
              {row.name}
              </TableCell>
              <TableCell>
              {row.email}
              </TableCell>
              <TableCell>
              {row.mobile}
              </TableCell>
              <TableCell>
              {row.address}
              </TableCell>





            

            </TableRow>
             ))}
          </TableBody>


        </Table>


    </>
    );
  }
}

const mapStateToProps = (state) => ({
  rows: state.tableReducer
});



export default connect(mapStateToProps)(TableContainer);

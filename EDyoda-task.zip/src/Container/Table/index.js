import React from "react";

class Thead extends React.Component {
  render() {
    return (
      <thead>
        <tr className="thead-dark">
          {this.props.cols.map((col, index) => (
            <th key={index}>{col}</th>
          ))}
        </tr>
      </thead>
    );
  }
}

export default Thead;

import React, { Component } from 'react'
import DashboardContainer from '../Container/Dashboard'

export default class Dashboard extends Component {
  render() {
    return (
      <>
      <DashboardContainer />
      </>
    )
  }
}

import React from 'react';

import EdAmountContainer from '../Container/EdAmount/EdAmountContainer';

const Edyodaamt = ()=>{
    return (

    <div >

     <EdAmountContainer/> 
    </div>
    );
}

export default Edyodaamt;
import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { Avatar, Divider, Stack, colors } from '@mui/material';
import pay from '../Images/pay.png';
import Checkbox from '@mui/material/Checkbox';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import AccessTimeIcon from '@mui/icons-material/AccessTime';

export default function AmountCard() {
  return (
    <Card sx={{ minWidth: 275 ,mt:5,}}>
      <CardContent >
      <Stack direction="row" spacing={2}>
  <Box ml={5} mr={5}><Avatar sx={{background:"#0096Ff" }}>1</Avatar>
</Box>
  <Box   ml={5} mr={5}><Avatar sx={{background:"#0096Ff", marginLeft:'100px', }}>2</Avatar></Box>

</Stack>

<Stack direction="row" spacing={2}>
  <Box ml={5} mr={5}><Typography sx={{fontSize:'12px',}}>Sign Up</Typography>
</Box>
  <Box ><Typography  sx={{marginLeft:'90px' , fontSize:'12px',}}>  Subscribe</Typography></Box>

</Stack>

<Stack direction="row" spacing={2}>
  <Box ml={5} mt={1}><Typography sx={{fontSize:'18px',fontFamily:'roboto', fontWeight:600,color:'#3C4852',}}>Select your subcription plan</Typography>
</Box>
 

</Stack>



<Stack spacing={2}>
  <Box sx={{border:'1px solid #BEBEBE' ,width:'100%' ,height:'50px' ,mt:2, background:'#E7E7E7', borderRadius:'5px'}}>
    <Box sx={{background:'#F77171' , width:'30%',ml:6,textAlign:'center',}}>

    <Typography sx={{fontSize:'8px',color:'#ffffff'}}>Offer expired</Typography>
    </Box>
  <Stack direction="row" spacing={2}>
  <Box sx={{width:'10%'}} >


  <Checkbox 
        label="CheckCircleIcon"
        icon={<RadioButtonUncheckedIcon />}
        checkedIcon={<CheckCircleIcon  sx={{color:'#BEBEBE'}} />}
      />
</Box>
  <Box   sx={{width:'60%' }} >
   <Typography sx={{mt:1 ,fontSize:'14px',fontFamily:'roboto', color:'#BEBEBE'}}>12 Months Subscription </Typography>
  </Box>
  <Box   sx={{width:'30%' }} >
  <Typography sx={{mt:1,fontFamily:'roboto', color:'#BEBEBE',fontSize:'14px'}}>Total ₹99 </Typography>
  <Typography  sx={{fontFamily:'roboto', color:'#BEBEBE',fontSize:'6px',ml:1}}>₹8 <span style={{marginLeft:'3px'}}>/mo</span></Typography>
  </Box>

</Stack>
</Box>
<Box sx={{border:'1px solid #47BA68' ,width:'100%',height:'50px' ,mt:2, background: '#D7EDDD', borderRadius:'5px'}}>
<Box sx={{background:'#47BA68' , width:'30%',ml:6,textAlign:'center',}}>

<Typography sx={{fontSize:'8px',color:'#ffffff'}}>Recommended</Typography>
</Box>
<Stack direction="row" spacing={2}>
  <Box sx={{width:'10%'}} >


  <Checkbox 
        label="CheckCircleIcon"
        icon={<RadioButtonUncheckedIcon />}
        checkedIcon={<CheckCircleIcon  sx={{color:'#47BA68'}} />}
      />
</Box>
  <Box   sx={{width:'60%' }} >
   <Typography sx={{mt:1, fontSize:'14px',fontFamily:'roboto',color:'#3C4852',fontWeight:600}}>12 Months Subscription </Typography>
  </Box>
  <Box   sx={{width:'30%' }} >
  <Typography sx={{mt:1 ,fontSize:'10px',fontFamily:'roboto',color:'#3C4852'}}>Total<span style={{fontWeight:600,fontSize:'14px',marginLeft:'5px'}}> ₹179</span> </Typography>
  <Typography  sx={{fontFamily:'roboto', color:'#3C4852',fontSize:'6px',ml:1,fontWeight:600}}>₹15 <span style={{marginLeft:'3px',fontWeight:100}}>/mo</span></Typography>
  </Box>

</Stack>
</Box>
<Box sx={{border:'1px solid #BEBEBE' ,width:'100%',height:'50px' ,mt:2, borderRadius:'5px'}}>

<Stack direction="row" spacing={2}>
  <Box sx={{width:'10%'}} >


  <Checkbox 
        label="CheckCircleIcon"
        icon={<RadioButtonUncheckedIcon />}
        checkedIcon={<CheckCircleIcon   />}
      />
</Box>
  <Box   sx={{width:'60%' }} >
   <Typography sx={{mt:1 ,fontSize:'14px',fontFamily:'roboto',color:'#3C4852',fontWeight:600}}>6 Months Subscription </Typography>
  </Box>
  <Box   sx={{width:'30%' }} >
  <Typography sx={{mt:1 ,fontSize:'10px',fontFamily:'roboto',color:'#3C4852'}}>Total<span style={{fontWeight:600,fontSize:'14px', marginLeft:'5px'}}>₹159 </span> </Typography>
  <Typography  sx={{fontFamily:'roboto', color:'#3C4852',fontSize:'6px',ml:1,fontWeight:600}}>₹25 <span style={{marginLeft:'3px',fontWeight:100}}>/mo</span></Typography>
  </Box>

</Stack>
</Box>
<Box sx={{border:'1px solid #BEBEBE' ,width:'100%' ,height:'50px' ,mt:2,  borderRadius:'5px'}}>
<Stack direction="row" spacing={2}>
  <Box sx={{width:'10%'}} >


  <Checkbox 
        label="CheckCircleIcon"
        icon={<RadioButtonUncheckedIcon />}
        checkedIcon={<CheckCircleIcon />}
      />
</Box>
  <Box   sx={{width:'60%' }} >
   <Typography sx={{mt:1 ,fontSize:'14px',fontFamily:'roboto',color:'#3C4852',fontWeight:600}}>3 Months Subscription </Typography>
  </Box>
  <Box   sx={{width:'30%' }} >
  <Typography sx={{mt:1,fontSize:'10px',fontFamily:'roboto',color:'#3C4852'}}>Total <span style={{fontWeight:600,fontSize:'14px',marginLeft:'5px'}}>₹99 </span></Typography>
  <Typography  sx={{fontFamily:'roboto', color:'#3C4852',fontSize:'6px',ml:1,fontWeight:600}}>₹33 <span style={{marginLeft:'3px',fontWeight:100}}>/mo</span></Typography>
  </Box>

</Stack>
</Box>
<Divider />

 

</Stack>

<Stack direction="row" spacing={2} mt={1}>
  <Box ml={5} sx={{width:'70%'}}><Typography sx={{fontSize:'14px',}}>Subscription Fee</Typography>
</Box>
  <Box  sx={{width:'30%'}} ><Typography  sx={{marginLeft:'30px' , fontSize:'12px',}}> ₹18,500</Typography></Box>

</Stack>



<Box sx={{border:'1px solid #DE4313' ,width:'100%',height:'50px' ,mt:2, background: '#ffcccb	',  borderRadius:'5px'}}>

<Stack direction="row" spacing={2}>
   <Box sx={{width:'60%'}} >

<Typography sx={{mt:1 ,ml:3, color:'#DE4313' ,fontSize:'10px'}} >Limited time offer</Typography>
</Box> 
<Box  sx={{width:'40%'}} ><Typography  sx={{marginLeft:'30px' , fontSize:'12px', m1:1 ,mt:1,fontWeight:600}}> - ₹18,401</Typography></Box>
</Stack>
  <Box   sx={{width:'90%',  }} >
   <Typography sx={{ pr:4, fontSize:'8px' ,fontWeight:600, color:'#DE4313'}}><span><AccessTimeIcon sx={{ ml:1, mr:1, color:'#DE4313' ,fontSize:'12px',}} /></span>Offer valid till 25th March 2023  </Typography>
  </Box>



</Box>

<Stack direction="row" spacing={2} mt={1}>
  <Box ml={5} sx={{width:'70%'}}><Typography sx={{fontSize:'14px',}}><span style={{fontWeight:600}}>Total</span> (Incl. of 18% GST)</Typography>
</Box>
  <Box  sx={{width:'30%'}} ><Typography  sx={{marginLeft:'50px' , fontSize:'12px',fontWeight:600}}> ₹149</Typography></Box>
 
</Stack>
       
<Stack direction="row" spacing={2} mt={2}>
  <Box ml={5} sx={{width:'40%'}}>
  <Button variant="outlined" 
    

  sx={{ "&:hover": {border:'1px solid #F77171 ',
  color:'#F77171',} ,
  border:'1px solid #F77171 ',
  color:'#F77171',

}}
  >cancel</Button>
</Box>
  <Box  sx={{width:'60%'}} >
  <Button variant="outlined" 
  sx={{ "&:hover": {color:'#ffffff',
  background: '#47BA68;'} ,
  border:'1px solid #ffffff ',
  background:'#47BA68',
  color:'#ffffff',

}}
  >proceed to pay</Button>

   </Box>
 
</Stack>

<Box>
<img
                        style={{
                            marginTop: '10px',
                            marginLeft:'35px',



                        }}

                        src={pay} alt="pay logo" />
</Box>
      </CardContent>
      
    </Card>
  );
}

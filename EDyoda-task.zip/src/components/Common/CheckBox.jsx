import { useState } from "react";
import Checkbox from '@mui/material/Checkbox';
import { Box, Stack, Typography } from "@mui/material";
import { Label } from "@mui/icons-material";
import Grid from '@mui/material/Grid';
import FormControlLabel from '@mui/material/FormControlLabel';

const getFormattedPrice = (price) => `$${price.toFixed(2)}`;

export default function App() {

    const toppings = [
        {
          name: "12 Months Subscription ",
          price: 1.2
        },
        {
          name: "12 Months Subscription ",
          price: 2.0
        },
        {
          name: "6 Months Subscription ",
          price: 2.5
        },
        {
          name: "3 Months Subscription ",
          price: 3.0
        },
        {
          name: "Offer valid till 25th March 2023 ",
          price: 3.5
        },
        {
          name: "Baby Corns",
          price: 3.0
        },
        {
          name: "Mushroom",
          price: 2.0
        }
      ];
  const [checkedState, setCheckedState] = useState(
    new Array(toppings.length).fill(false)
  );

  const [total, setTotal] = useState(0);

  const handleOnChange = (position) => {
    const updatedCheckedState = checkedState.map((item, index) =>
      index === position ? !item : item
    );

    setCheckedState(updatedCheckedState);

    const totalPrice = updatedCheckedState.reduce(
      (sum, currentState, index) => {
        if (currentState === true) {
          return sum + toppings[index].price;
        }
        return sum;
      },
      0
    );

    setTotal(totalPrice);
  };

  return (
    <>
      <h3>Select your subcription plan</h3>
  
      <Box>
        {toppings.map(({ name, price }, index) => {
          return (
            <Box key={index} sx={{border:"1px solid red"}}>
                
                <Stack direction="row" spacing={0}>
                  <Box sx={{width:"70%" }}>
                    
             
                 <FormControlLabel
            control={
              <Checkbox
              name={name}
              value={name}
              id={`custom-checkbox-${index}`}
              checked={checkedState[index]}
              onChange={() => handleOnChange(index)}
             />
            }
            label={name}

          />
          </Box>

               <Box sx={{width:"30%"}}> <Typography mt={1}>{getFormattedPrice(price)}</Typography> </Box>

                
               
              

</Stack>
              
            </Box>
          );
        })}
        <Stack direction="row" spacing={2}>
        <Box sx={{width:"70%"}}>
            <Typography className="left-section">Total (Incl. of 18% GST)</Typography>
            </Box>
            <Box sx={{width:"30%"}}>  <Typography className="right-section">{getFormattedPrice(total)}</Typography>
            </Box>
        </Stack>
      </Box>

    

      
    
      </>
  );
}


import * as React from "react";
import Button from "@mui/material/Button";
import PropTypes from "prop-types";



function CommonButton(props) {


 CommonButton.propTypes = {
    ButtonIcon: PropTypes.element
  };
  return (
    
     
<Button variant="contained"
type="submit"

style={{
marginTop: "0.23rem",
        borderRadius: 35, 
        marginLeft:3, 
        padding: "4px 20px",
        color:"#ffffff",
        fontSize: "14px"
        }}
        

>
    
    {props.ButtonIcon}
    {props.ButtonTxt}  
</Button>


  );
}

export default CommonButton;

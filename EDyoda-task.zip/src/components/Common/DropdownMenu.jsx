import * as React from 'react';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

export default function DropDownMenu(props) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <Button
      sx={{color:"#000000"}}
        id="basic-button"
        aria-controls={open ? 'basic-menu' : undefined}
        // aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        color="primary"
        onClick={handleClick}
        endIcon={<KeyboardArrowDownIcon />}
        

      >
     {props.title}
      </Button>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }}
      >
        <MenuItem onClick={handleClose}>{props.name1}</MenuItem>
        <MenuItem onClick={handleClose}>{props.name2}</MenuItem>
        <MenuItem onClick={handleClose}>{props.name3}</MenuItem>
      </Menu>
    </div>
  );
}

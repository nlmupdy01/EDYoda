import * as React from 'react';
import TextField from '@mui/material/TextField';

export default function Textfields(props) {
  return (
 <>


<TextField
fullWidth
            sx={{width:'300px'}}
            id="Sid"
            name={props.name}
            type={props.type}
            size='small'
            label={props.label}
            autoComplete="family-name"
            variant="outlined" 
          />
      </>
  );
}
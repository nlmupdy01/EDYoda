import * as React from 'react';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import { Typography } from '@mui/material';
import Vector from '../Images/Vector.png';
import tv from '../Images/tv.png';
import ed from '../Images/ed.png';
import clock from '../Images/clock.png';
import add from '../Images/add.png';

export default function EdyodaContent() {
    return (
        <Box sx={{ width: '100%', marginLeft: '100px' }}>
            <Stack spacing={2}>
                <Box> <Typography variant="" gutterBottom color={"#ffffff"}
                    style={{
                        fontFamily: 'Raleway',
                        fontWeight: '600',
                        fontSize: '45px',
                        lineHeight: '15%',
                        display: 'flex',
                        textAlign: 'center'
                    }}
                >
                    Access curated courses worth
                </Typography></Box>
                <Box>
                    <Typography variant="" gutterBottom color={"#ffffff"}
                        style={{
                            fontFamily: 'Roboto',
                            fontWeight: '600',
                            alignItems: 'center',
                            letterSpacing: '0.01em',
                            fontSize: '45px',
                            lineHeight: '125%',
                            display: 'flex',
                            textAlign: 'center'
                        }}
                    >
                        ₹ <s
                            style={{
                                paddingLeft: '10px',
                                paddingRight: '20px',
                                color: 'red'

                            }}><span style={{
                                color: '#ffffff',

                            }}>18,500</span></s> at just <span style={{

                                color: '#0096FF',
                                paddingLeft: '10px',
                                paddingRight: '20px',
                            }}>₹  99 </span> per year!

                    </Typography>
                </Box>

            </Stack>
            <Stack direction="row" spacing={2}>
                <Box >

                    <img
                        style={{
                            marginTop: '20px',
                            width: '50px',
                            height: '50px',



                        }}

                        src={Vector} alt="Edyoda logo" />
                </Box>
                <Box pl={5}>
                    <Typography
                        sx={{
                            marginTop: '20px',
                            Left: '50x',
                            color: '#ffffff',
                            fontFamily: 'roboto',
                            fontWeight: 600,
                            fontSize: '26px'

                        }}
                    >
                        <span style={{

color: '#0096FF',
paddingRight: '5px',
}}>
    100+ </span> Job relevant courses
                    </Typography>
                </Box>

            </Stack>


            <Stack direction="row" spacing={2}>
                <Box >

                    <img
                        style={{
                         marginTop:'20px',
                            width: '50px',
                            height: '50px',
                           
                            
                       
                        }}

                        src={clock} alt="Edyoda logo" />
                </Box>
                <Box pl={5}>
                  <Typography 
                  sx={{
                    marginTop:'20px',
                    Left:'50x',
                    color:'#ffffff',
                    fontFamily:'roboto',
                    fontWeight:600,
                    fontSize:'26px'

                  }}
                  >
                   <span style={{

color: '#0096FF',
paddingRight: '5px',
}} 
>20,000+ </span> Hours of content 
                    </Typography>  
                </Box>

            </Stack>

            <Stack direction="row" spacing={2}>
                <Box >

                    <img
                        style={{
                         marginTop:'20px',
                            width: '50px',
                            height: '50px',
                           
                            
                       
                        }}

                        src={tv} alt="Edyoda logo" />
                </Box>
                <Box pl={5}>
                  <Typography 
                  sx={{
                    marginTop:'20px',
                    Left:'50x',
                    color:'#ffffff',
                    fontFamily:'roboto',
                    fontWeight:600,
                    fontSize:'26px'

                  }}
                  >
                   <span style={{

color: '#0096FF',
paddingRight: '5px',
}} 
>Exclusive </span>  webinar access
                    </Typography>  
                </Box>

            </Stack>

            
            <Stack direction="row" spacing={2}>
                <Box >

                    <img
                        style={{
                         marginTop:'20px',
                            width: '50px',
                            height: '50px',
                           
                            
                       
                        }}

                        src={ed} alt="Edyoda logo" />
                </Box>
                <Box pl={5}>
                  <Typography 
                  sx={{
                    marginTop:'20px',
                    Left:'50x',
                    color:'#ffffff',
                    fontFamily:'roboto',
                    fontWeight:600,
                    fontSize:'26px'

                  }}
                  >
           Scholarship worth 

           <span style={{

color: '#0096FF',
paddingRight: '5px',
}} 
>₹94,500 </span>
                    </Typography>  
                </Box>

            </Stack>

            <Stack direction="row" spacing={2}>
                <Box >

                    <img
                        style={{
                         marginTop:'20px',
                            width: '50px',
                            height: '50px',
                           
                            
                       
                        }}

                        src={add} alt="Edyoda logo" />
                </Box>
                <Box pl={5}>


                  <Typography 
                  sx={{
                    marginTop:'20px',
                    Left:'50x',
                    color:'#ffffff',
                    fontFamily:'roboto',
                    fontWeight:600,
                    fontSize:'26px'

                  }}


                  >
                     <span style={{

color: '#0096FF',
paddingRight: '5px',
}} 
>Ad Free</span>
            learning experience

          
                    </Typography>  
                </Box>

            </Stack>
        </Box>
    );
}